import React from "react";
import { BrowserRouter } from "react-router-dom";

function Home() {
  return (
    <>
      <h1>This is home page for counter</h1>
    </>
  );
}

export default Home;
